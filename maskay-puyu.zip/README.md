# maskay-puyu
A Python package for predicting clouds and cloud shadows in Sentinel 2 imagery
